const companyName='scuber'

let mostProfitableNeighborhood=chelsea

let companyCeo='Susan Smith'
